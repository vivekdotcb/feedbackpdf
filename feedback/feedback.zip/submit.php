<?php
session_start();
require_once 'db_config.php';
// Connect
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Clean helper
function clean_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

// Handle user info submission (Step 1)
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_user'])) {
    $name   = clean_input($_POST['name']   ?? '');
    $mobile = clean_input($_POST['mobile'] ?? '');
    $batch  = clean_input($_POST['batch']  ?? '');

    if (empty($name) || empty($mobile) || empty($batch)) {
        $_SESSION['message'] = "Please fill all fields.";
    } else {
        $stmt = $conn->prepare("INSERT INTO users (name, mobile, batch) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $mobile, $batch);
        if ($stmt->execute()) {
            $_SESSION['user_id'] = $stmt->insert_id;
            $_SESSION['show_feedback_form'] = true;
        } else {
            $_SESSION['message'] = "Error saving user data: " . $stmt->error;
        }
        $stmt->close();
    }
}

// Handle feedback + remarks submission (Step 2)
elseif (isset($_POST['submit_feedback'])) {
    $user_id = intval($_POST['user_id'] ?? 0);
    $mess    = clean_input($_POST['mess'] ?? '');
    $q       = intval($_POST['food_quality'] ?? 0);
    $t       = intval($_POST['food_taste'] ?? 0);
    $mc      = intval($_POST['mess_cleanliness'] ?? 0);
    $wc      = intval($_POST['washroom_cleanliness'] ?? 0);
    $remarks = clean_input($_POST['remarks'] ?? '');

    // Validate required fields
    if (
        $user_id <= 0 || empty($mess) ||
        $q < 1 || $q > 5 ||
        $t < 1 || $t > 5 ||
        $mc < 1 || $mc > 5 ||
        $wc < 1 || $wc > 5
    ) {
        $_SESSION['message'] = "Please fill all feedback fields.";
        $_SESSION['show_feedback_form'] = true;
    } else {
        $stmt = $conn->prepare(
            "INSERT INTO feedback (user_id, mess, food_quality, food_taste, mess_cleanliness, washroom_cleanliness, remarks)
             VALUES (?, ?, ?, ?, ?, ?, ?)"
        );
        $stmt->bind_param("isiiiis", $user_id, $mess, $q, $t, $mc, $wc, $remarks);
        if ($stmt->execute()) {
            $_SESSION['feedback_submitted'] = true;
            $_SESSION['message'] = "Thank you for your feedback!";
            unset($_SESSION['show_feedback_form'], $_SESSION['user_id']);
        } else {
            $_SESSION['message'] = "Error saving feedback: " . $stmt->error;
            $_SESSION['show_feedback_form'] = true;
        }
        $stmt->close();
    }
}

// Redirect back
header("Location: index.php");
exit;
