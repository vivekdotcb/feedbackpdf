<?php
require_once '../auth/auth_check.php';
require_once '../db_config.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $sql = "DELETE FROM courses WHERE id=$id";
    $msg = $conn->query($sql) ? 'deleted' : 'error';
    header("Location: add_course.php?message=$msg");
    exit();
}
?>
