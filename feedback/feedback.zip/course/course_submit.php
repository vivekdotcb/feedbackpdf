<?php
require_once '../auth/auth_check.php';
require_once '../db_config.php';

if (isset($_POST['submit_feedback'])) {
    $name = $conn->real_escape_string(trim($_POST['name']));
    $check = $conn->query("SELECT * FROM courses WHERE name = '$name'");
    if ($check->num_rows > 0) {
        header("Location: add_course.php?message=duplicate");
        exit();
    }

    $sql = "INSERT INTO courses (name) VALUES ('$name')";
    $msg = $conn->query($sql) ? 'success' : 'error';
    header("Location: add_course.php?message=$msg");
    exit();
}

if (isset($_POST['update_course'])) {
    $id = intval($_POST['id']);
    $name = $conn->real_escape_string(trim($_POST['name']));
    $check = $conn->query("SELECT * FROM courses WHERE name = '$name' AND id != $id");
    if ($check->num_rows > 0) {
        header("Location: add_course.php?message=duplicate");
        exit();
    }

    $sql = "UPDATE courses SET name='$name' WHERE id=$id";
    $msg = $conn->query($sql) ? 'updated' : 'error';
    header("Location: add_course.php?message=$msg");
    exit();
}
?>
