<?php
require_once '../auth/auth_check.php';   // Login check
require_once '../db_config.php';          // DB connection

$result = $conn->query("SELECT * FROM courses ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Add Course</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" />
  <style>
    /* Make space for sidebar */
    body {
      display: flex;
    }
    .main-content {
      margin-left: 220px; /* Width of sidebar */
      padding: 20px;
      width: 100%;
    }
  </style>
</head>
<body>

<?php include '../auth/sidebar.php'; ?>

<div class="main-content container mt-4">
  <h2 class="mb-4">Add Course</h2>

  <?php if (isset($_GET['message'])): ?>
    <?php
      $msgType = '';
      $msgText = '';
      switch ($_GET['message']) {
        case 'success': $msgType = 'success'; $msgText = 'Course added successfully!'; break;
        case 'updated': $msgType = 'info'; $msgText = 'Course updated successfully!'; break;
        case 'deleted': $msgType = 'warning'; $msgText = 'Course deleted successfully!'; break;
        case 'duplicate': $msgType = 'danger'; $msgText = 'Duplicate course name not allowed!'; break;
        case 'error': $msgType = 'danger'; $msgText = 'Something went wrong!'; break;
      }
    ?>
    <div class="alert alert-<?= $msgType ?>" role="alert"><?= $msgText ?></div>
  <?php endif; ?>

  <!-- Add course form -->
  <form method="post" action="course_submit.php" class="mb-4">
    <div class="mb-3">
      <label for="name" class="form-label">Course Name:</label>
      <input type="text" id="name" name="name" class="form-control" required />
    </div>
    <button type="submit" name="submit_feedback" class="btn btn-primary">Submit</button>
  </form>

  <!-- Course list -->
  <h4>Course List</h4>
  <table id="courseTable" class="table table-striped table-bordered">
    <thead>
      <tr>
        <th>Serial No.</th>
        <th>Course Name</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php $serial = 0; while ($row = $result->fetch_assoc()): ?>
      <tr>
        <td><?= ++$serial ?></td>
        <td><?= htmlspecialchars($row['name']) ?></td>
        <td>
          <button 
            class="btn btn-sm btn-info editBtn" 
            data-id="<?= $row['id'] ?>" 
            data-name="<?= htmlspecialchars($row['name']) ?>">
            Edit
          </button>
          <a href="delete_course.php?id=<?= $row['id'] ?>" 
             onclick="return confirm('Delete this course?');" 
             class="btn btn-sm btn-danger">
            Delete
          </a>
        </td>
      </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<!-- Edit modal -->
<div class="modal fade" id="editModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <form method="post" action="course_submit.php" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Edit Course</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="id" id="edit-id" />
        <div class="mb-3">
          <label for="edit-name" class="form-label">Course Name:</label>
          <input type="text" id="edit-name" name="name" class="form-control" required />
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" name="update_course" class="btn btn-primary">Update</button>
      </div>
    </form>
  </div>
</div>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<script>
  $(document).ready(function() {
    $('#courseTable').DataTable();

    // Auto hide alerts after 3 seconds
    setTimeout(() => $('.alert').fadeOut('slow'), 3000);

    // Edit button click event
    $('.editBtn').click(function() {
      const id = $(this).data('id');
      const name = $(this).data('name');
      $('#edit-id').val(id);
      $('#edit-name').val(name);
      const editModal = new bootstrap.Modal(document.getElementById('editModal'));
      editModal.show();
    });
  });
</script>

</body>
</html>
  