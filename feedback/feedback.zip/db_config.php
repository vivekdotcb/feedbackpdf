<?php
$host = "localhost";
$username = "u880959487_divya";
$password = "Divya@151292";
$dbname = "u880959487_feedback";

// Create connection
$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>