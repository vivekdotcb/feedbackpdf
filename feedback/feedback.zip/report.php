<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Mess Feedback Report</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f6f9;
      padding: 5px;
    }

    .container {
      max-width: 100%px;
      margin: auto;
    }

    h2 {
      text-align: center;
      color: #007bff;
      margin-bottom: 20px;
    }

    .table-container {
      overflow-x: auto;
      background: white;
      border-radius: 10px;
      padding: 20px;
      box-shadow: 0 0 8px rgba(0, 0, 0, 0.1);
    }

    table {
      width: 100%;
      border-collapse: collapse;
      min-width: 100%;
    }

    th, td {
      padding: 12px;
      border: 1px solid #ddd;
      text-align: center;
      white-space: nowrap;
    }

    th {
      background-color: #007bff;
      color: white;
      font-size: 14px;
      text-transform: uppercase;
    }

    .stars {
      color: gold;
      font-size: 16px;
    }

    tr:hover {
      background-color: #f1f1f1;
    }

    .avg-row {
      background-color: #e9f7ef;
      font-weight: bold;
    }

    @media (max-width: 768px) {
      th, td {
        font-size: 12px;
        padding: 8px;
      }

      .stars {
        font-size: 14px;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Mess Feedback Report</h2>

    <div class="table-container">
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Mobile</th>
            <th>Batch</th>
            <th>Mess</th>
            <th>Food Quality</th>
            <th>Food Taste</th>
            <th>Mess Cleanliness</th>
            <th>Washroom Cleanliness</th>
            <!-- <th>Remarks</th>  -->
          </tr>
        </thead>
        <tbody>
          <?php
          require_once 'db_config.php';
          if ($conn->connect_error) {
              die("Connection failed: " . $conn->connect_error);
          }

          $sql = "SELECT u.name, u.mobile, u.batch, f.mess, f.food_quality, f.food_taste, f.mess_cleanliness, f.washroom_cleanliness, f.remarks 
                  FROM feedback f
                  JOIN users u ON f.user_id = u.id
                  ORDER BY f.id DESC";

          $result = $conn->query($sql);

          $totals = [];
          $counts = [];

          if ($result->num_rows > 0) {
              while ($row = $result->fetch_assoc()) {
                  echo "<tr>
                          <td>" . htmlspecialchars($row['name']) . "</td>
                          <td>" . htmlspecialchars($row['mobile']) . "</td>
                          <td>" . htmlspecialchars($row['batch']) . "</td>
                          <td>" . htmlspecialchars($row['mess']) . "</td>
                          <td class='stars'>" . str_repeat('★', (int)$row['food_quality']) . "</td>
                          <td class='stars'>" . str_repeat('★', (int)$row['food_taste']) . "</td>
                          <td class='stars'>" . str_repeat('★', (int)$row['mess_cleanliness']) . "</td>
                          <td class='stars'>" . str_repeat('★', (int)$row['washroom_cleanliness']) . "</td>
                          
                        </tr>";

                  $mess = $row['mess'];
                  if (!isset($totals[$mess])) {
                      $totals[$mess] = [
                          'food_quality' => 0,
                          'food_taste' => 0,
                          'mess_cleanliness' => 0,
                          'washroom_cleanliness' => 0
                      ];
                      $counts[$mess] = 0;
                  }

                  $totals[$mess]['food_quality'] += $row['food_quality'];
                  $totals[$mess]['food_taste'] += $row['food_taste'];
                  $totals[$mess]['mess_cleanliness'] += $row['mess_cleanliness'];
                  $totals[$mess]['washroom_cleanliness'] += $row['washroom_cleanliness'];
                  $counts[$mess]++;
              }

              foreach ($totals as $mess => $sum) {
                  $count = $counts[$mess];
                  echo "<tr class='avg-row'>
                          <td colspan='3'>Average (Total Users: $count)</td>
                          <td>$mess</td>
                          <td class='stars'>" . str_repeat('★', round($sum['food_quality'] / $count)) . "</td>
                          <td class='stars'>" . str_repeat('★', round($sum['food_taste'] / $count)) . "</td>
                          <td class='stars'>" . str_repeat('★', round($sum['mess_cleanliness'] / $count)) . "</td>
                          <td class='stars'>" . str_repeat('★', round($sum['washroom_cleanliness'] / $count)) . "</td>
                          <td>-</td>
                        </tr>";
              }
          } else {
              echo "<tr><td colspan='9'>No feedback submitted yet.</td></tr>";
          }

          $conn->close();
          ?>
        </tbody>
      </table>
    </div>
  </div>
</body>
</html>
