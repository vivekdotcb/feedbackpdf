<?php
session_start();
$user_id = $_SESSION['user_id'] ?? null;
$show_feedback_form = $_SESSION['show_feedback_form'] ?? false;
$feedback_submitted = $_SESSION['feedback_submitted'] ?? false;
$message = $_SESSION['message'] ?? "";

// Clear message after showing
unset($_SESSION['message']);

require_once 'db_config.php'; 
// Create connection


// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch course names from course table
$course_options = [];
$sql = "SELECT name FROM courses ORDER BY id DESC";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $course_options[] = $row['name'];
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User Feedback</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
  <div class="container">
    <h2> Mess Feedback</h2>

    <?php if ($feedback_submitted): ?>
      <!-- ✅ Show thank-you message only -->
      <p class="message" style="color: green; font-weight: bold;">Thank you for your feedback!</p>
      <?php
      // Clear session flags to avoid repeated form display
      unset($_SESSION['feedback_submitted']);
      unset($_SESSION['show_feedback_form']);
      unset($_SESSION['user_id']);
      exit;
      ?>
    <?php elseif ($show_feedback_form): ?>
      <!-- ✅ Show feedback form after initial user data submitted -->
      <form method="post" action="submit.php">
        <input type="hidden" name="user_id" value="<?= $user_id ?>">

        <label for="mess">Select Mess:</label>
        <select name="mess" required>
          <option value="">--Select Mess--</option>
          <option value="madhuram">Madhuram</option>
          <option value="paysam">Paysam</option>
          <option value="aharm">Aharm</option>
          <option value="ananda">Ananda</option>
        </select>

        <div class="rating-group">
          <label>Food Quality:</label>
          <div class="stars">
            <?php for ($i = 5; $i >= 1; $i--): ?>
              <input type="radio" name="food_quality" id="food_quality-<?= $i ?>" value="<?= $i ?>" required>
              <label for="food_quality-<?= $i ?>">★</label>
            <?php endfor; ?>
          </div>
        </div>

        <div class="rating-group">
          <label>Food Taste:</label>
          <div class="stars">
            <?php for ($i = 5; $i >= 1; $i--): ?>
              <input type="radio" name="food_taste" id="food_taste-<?= $i ?>" value="<?= $i ?>" required>
              <label for="food_taste-<?= $i ?>">★</label>
            <?php endfor; ?>
          </div>
        </div>

        <div class="rating-group">
          <label>Mess Cleanliness:</label>
          <div class="stars">
            <?php for ($i = 5; $i >= 1; $i--): ?>
              <input type="radio" name="mess_cleanliness" id="mess_cleanliness-<?= $i ?>" value="<?= $i ?>" required>
              <label for="mess_cleanliness-<?= $i ?>">★</label>
            <?php endfor; ?>
          </div>
        </div>

        <div class="rating-group">
          <label>Washroom Cleanliness:</label>
          <div class="stars">
            <?php for ($i = 5; $i >= 1; $i--): ?>
              <input type="radio" name="washroom_cleanliness" id="washroom_cleanliness-<?= $i ?>" value="<?= $i ?>" required>
              <label for="washroom_cleanliness-<?= $i ?>">★</label>
            <?php endfor; ?>
          </div>
        </div>

        <!-- <label for="remarks">Remarks (Optional):</label><br> -->
        <textarea name="remarks" rows="3" style="display: none; width:100%; padding:10px; border-radius:6px; border:1px solid #ccc; margin-bottom:20px;"></textarea>

        <input type="submit" name="submit_feedback" value="Submit Feedback">
      </form>

    <?php else: ?>
      <!-- ✅ Initial form for name, mobile, batch -->
      <?php if ($message): ?>
        <p class="message"><?= $message ?></p>
      <?php endif; ?>

      <form method="post" action="submit.php">
        <label for="name">Name:</label>
        <input type="text" name="name" required>

        <label for="mobile">Mobile:</label>
        <input type="tel" name="mobile" pattern="\d{10}" maxlength="10" minlength="10" required>

        <label for="batch">Batch:</label>
        <select name="batch" required>
          <option value="">--Select Batch--</option>
          <?php foreach ($course_options as $course): ?>
              <option value="<?= htmlspecialchars($course) ?>"><?= htmlspecialchars($course) ?></option>
          <?php endforeach; ?>
        </select>

        <input type="submit" name="submit_user" value="Next">
      </form>
    <?php endif; ?>
  </div>
</body>
</html>
