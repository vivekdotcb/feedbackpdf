<?php
session_start();
$servername = "localhost";
$username = "u880959487_divya";
$password = "Divya@151292";
$dbname = "u880959487_feedback";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function clean_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['submit_user'])) {
    $name = clean_input($_POST['name'] ?? '');
    $mobile = clean_input($_POST['mobile'] ?? '');
    $batch = clean_input($_POST['batch'] ?? '');

    if (empty($name) || empty($mobile) || empty($batch)) {
        $_SESSION['message'] = "Please fill all fields.";
    } else {
        $stmt = $conn->prepare("INSERT INTO users (name, mobile, batch) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $mobile, $batch);
        if ($stmt->execute()) {
            $_SESSION['user_id'] = $stmt->insert_id;
            $_SESSION['show_hostel_feedback_form'] = true;
        } else {
            $_SESSION['message'] = "Error saving user: " . $stmt->error;
        }
        $stmt->close();
    }

} elseif (isset($_POST['submit_feedback'])) {
    $user_id = intval($_POST['user_id'] ?? 0);
    $hostel_name = clean_input($_POST['hostel_name'] ?? '');
    $room_no = clean_input($_POST['room_no'] ?? '');
    $remarks = clean_input($_POST['remarks'] ?? '');

    $ratings = [
        'bedsheet_cleanliness', 'room_cleanliness', 'condiment_tray',
        'ac', 'fan', 'geyser', 'kettle', 'handwash', 'washroom'
    ];

    $values = [];
    foreach ($ratings as $key) {
        $values[$key] = intval($_POST[$key] ?? 0);
        if ($values[$key] < 1 || $values[$key] > 5) {
            $_SESSION['message'] = "Please rate all fields from 1 to 5.";
            $_SESSION['show_hostel_feedback_form'] = true;
            header("Location: hostel.php");
            exit;
        }
    }

    if ($user_id <= 0 || empty($hostel_name) || empty($room_no)) {
        $_SESSION['message'] = "Please fill all required fields.";
        $_SESSION['show_hostel_feedback_form'] = true;
    } else {
        $stmt = $conn->prepare("
            INSERT INTO hostel_feedback (
                user_id, hostel_name, room_no,
                bedsheet_cleanliness, room_cleanliness, condiment_tray,
                ac, fan, geyser, kettle, handwash, washroom, remarks
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->bind_param(
            "issiiiiiiiiis",
            $user_id, $hostel_name, $room_no,
            $values['bedsheet_cleanliness'],
            $values['room_cleanliness'],
            $values['condiment_tray'],
            $values['ac'],
            $values['fan'],
            $values['geyser'],
            $values['kettle'],
            $values['handwash'],
            $values['washroom'],
            $remarks
        );

        if ($stmt->execute()) {
            $_SESSION['feedback_submitted'] = true;
            unset($_SESSION['show_hostel_feedback_form'], $_SESSION['user_id']);
        } else {
            $_SESSION['message'] = "Error saving feedback: " . $stmt->error;
            $_SESSION['show_hostel_feedback_form'] = true;
        }
        $stmt->close();
    }
}

header("Location: hostel.php");
exit;
