<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Hostel Feedback Report</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f6f9;
      padding: 5px;
    }

    .container {
      max-width: 100%;
      margin: auto;
    }

    h2 {
      text-align: center;
      color: #007bff;
      margin-bottom: 20px;
    }

    .table-container {
      overflow-x: auto;
      background: white;
      border-radius: 10px;
      padding: 20px;
      box-shadow: 0 0 8px rgba(0, 0, 0, 0.1);
    }

    table {
      width: 100%;
      border-collapse: collapse;
      min-width: 100%;
    }

    th, td {
      padding: 12px;
      border: 1px solid #ddd;
      text-align: center;
      white-space: nowrap;
    }

    th {
      background-color: #007bff;
      color: white;
      font-size: 14px;
      text-transform: uppercase;
    }

    .stars {
      color: gold;
      font-size: 16px;
    }

    tr:hover {
      background-color: #f1f1f1;
    }

    .avg-row {
      background-color: #e9f7ef;
      font-weight: bold;
    }

    @media (max-width: 768px) {
      th, td {
        font-size: 12px;
        padding: 8px;
      }

      .stars {
        font-size: 14px;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Hostel Feedback Report</h2>

    <div class="table-container">
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Mobile</th>
            <th>Batch</th>
            <th>Hostel</th>
            <th>Room No</th>
            <th>Bedsheet</th>
            <th>Room</th>
            <th>Condiment Tray</th>
            <th>AC</th>
            <th>Fan</th>
            <th>Geyser</th>
            <th>Kettle</th>
            <th>Handwash</th>
            <th>Washroom</th>
            <!-- <th>Remarks</th> -->
          </tr>
        </thead>
        <tbody>
          <?php
          $conn = new mysqli("localhost", "u880959487_divya", "Divya@151292", "u880959487_feedback");
          if ($conn->connect_error) {
              die("Connection failed: " . $conn->connect_error);
          }

          // SQL Query for hostel feedback
          $sql = "SELECT u.name, u.mobile, u.batch, h.hostel_name, h.room_no, h.bedsheet_cleanliness, h.room_cleanliness, 
                         h.condiment_tray, h.ac, h.fan, h.geyser, h.kettle, h.handwash, h.washroom, h.remarks
                  FROM hostel_feedback h
                  JOIN users u ON h.user_id = u.id
                  ORDER BY h.id DESC";

          $result = $conn->query($sql);

          $totals = [];
          $counts = [];

          if ($result->num_rows > 0) {
              while ($row = $result->fetch_assoc()) {
                  echo "<tr>
                          <td>" . htmlspecialchars($row['name']) . "</td>
                          <td>" . htmlspecialchars($row['mobile']) . "</td>
                          <td>" . htmlspecialchars($row['batch']) . "</td>
                          <td>" . htmlspecialchars($row['hostel_name']) . "</td>
                          <td>" . htmlspecialchars($row['room_no']) . "</td>
                          <td class='stars'>" . str_repeat('★', (int)$row['bedsheet_cleanliness']) . "</td>
                          <td class='stars'>" . str_repeat('★', (int)$row['room_cleanliness']) . "</td>
                          <td class='stars'>" . str_repeat('★', (int)$row['condiment_tray']) . "</td>
                          <td class='stars'>" . str_repeat('★', (int)$row['ac']) . "</td>
                          <td class='stars'>" . str_repeat('★', (int)$row['fan']) . "</td>
                          <td class='stars'>" . str_repeat('★', (int)$row['geyser']) . "</td>
                          <td class='stars'>" . str_repeat('★', (int)$row['kettle']) . "</td>
                          <td class='stars'>" . str_repeat('★', (int)$row['handwash']) . "</td>
                          <td class='stars'>" . str_repeat('★', (int)$row['washroom']) . "</td>
                          
                        </tr>";

                  $hostel = $row['hostel_name'];
                  if (!isset($totals[$hostel])) {
                      $totals[$hostel] = [
                          'bedsheet_cleanliness' => 0,
                          'room_cleanliness' => 0,
                          'condiment_tray' => 0,
                          'ac' => 0,
                          'fan' => 0,
                          'geyser' => 0,
                          'kettle' => 0,
                          'handwash' => 0,
                          'washroom' => 0
                      ];
                      $counts[$hostel] = 0;
                  }

                  $totals[$hostel]['bedsheet_cleanliness'] += $row['bedsheet_cleanliness'];
                  $totals[$hostel]['room_cleanliness'] += $row['room_cleanliness'];
                  $totals[$hostel]['condiment_tray'] += $row['condiment_tray'];
                  $totals[$hostel]['ac'] += $row['ac'];
                  $totals[$hostel]['fan'] += $row['fan'];
                  $totals[$hostel]['geyser'] += $row['geyser'];
                  $totals[$hostel]['kettle'] += $row['kettle'];
                  $totals[$hostel]['handwash'] += $row['handwash'];
                  $totals[$hostel]['washroom'] += $row['washroom'];
                  $counts[$hostel]++;
              }

              foreach ($totals as $hostel => $sum) {
                  $count = $counts[$hostel];
                  echo "<tr class='avg-row'>
                          <td colspan='3'>Average (Total Users: $count)</td>
                          <td>$hostel</td>
                          <td>-</td>
                          <td class='stars'>" . str_repeat('★', round($sum['bedsheet_cleanliness'] / $count)) . "</td>
                          <td class='stars'>" . str_repeat('★', round($sum['room_cleanliness'] / $count)) . "</td>
                          <td class='stars'>" . str_repeat('★', round($sum['condiment_tray'] / $count)) . "</td>
                          <td class='stars'>" . str_repeat('★', round($sum['ac'] / $count)) . "</td>
                          <td class='stars'>" . str_repeat('★', round($sum['fan'] / $count)) . "</td>
                          <td class='stars'>" . str_repeat('★', round($sum['geyser'] / $count)) . "</td>
                          <td class='stars'>" . str_repeat('★', round($sum['kettle'] / $count)) . "</td>
                          <td class='stars'>" . str_repeat('★', round($sum['handwash'] / $count)) . "</td>
                          <td class='stars'>" . str_repeat('★', round($sum['washroom'] / $count)) . "</td>
                          <td>-</td>
                        </tr>";
              }
          } else {
              echo "<tr><td colspan='15'>No feedback submitted yet.</td></tr>";
          }

          $conn->close();
          ?>
        </tbody>
      </table>
    </div>
  </div>
</body>
</html>
