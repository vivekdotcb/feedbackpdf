CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    mobile VARCHAR(20),
    batch VARCHAR(50)
);

CREATE TABLE feedback (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    mess VARCHAR(20),
    food_quality INT,
    food_taste INT,
    mess_cleanliness INT,
    washroom_cleanliness INT,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
