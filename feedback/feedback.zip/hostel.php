<?php
session_start();
$user_id = $_SESSION['user_id'] ?? null;
$show_feedback_form = $_SESSION['show_hostel_feedback_form'] ?? false;
$message = $_SESSION['message'] ?? "";
$feedback_submitted = $_SESSION['feedback_submitted'] ?? false;
unset($_SESSION['message']);

require_once 'db_config.php'; 
// Create connection


// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch course names from course table
$course_options = [];
$sql = "SELECT name FROM courses ORDER BY id DESC";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $course_options[] = $row['name'];
    }
}
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hostel Feedback</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="container">
    <h2>Hostel Feedback</h2>

    <?php if ($feedback_submitted): ?>
        <p class="message">Thank you for your feedback! We appreciate your time.</p>
        <?php
        unset($_SESSION['show_hostel_feedback_form']);
        unset($_SESSION['feedback_submitted']);
        ?>
    <?php else: ?>
        <?php if ($message): ?>
            <p class="message"><?= $message ?></p>
        <?php endif; ?>

        <?php if (!$show_feedback_form): ?>
            <!-- User Info Form -->
            <form method="post" action="submit_hostel.php">
               <label for="name">Name:</label>
               <input type="text" name="name" required>

               <label for="mobile">Mobile:</label>
               <input type="tel" name="mobile" pattern="\d{10}" maxlength="10" minlength="10" required>

                <label for="batch">Batch:</label>
                    <select name="batch" required>
                      <option value="">--Select Batch--</option>
                      <?php foreach ($course_options as $course): ?>
                        <option value="<?= htmlspecialchars($course) ?>"><?= htmlspecialchars($course) ?></option>
                    <?php endforeach; ?>
                    
                    
                    </select>
               <input type="submit" name="submit_user" value="Next">
            </form>
        <?php else: ?>
            <!-- Hostel Feedback Form -->
            <form method="post" action="submit_hostel.php">
                <input type="hidden" name="user_id" value="<?= $user_id ?>">

                <label>Hostel Name:</label>
                <select name="hostel_name" required>
                    <option value="">--Select Hostel--</option>
                    <option value="arawali">arawali</option>
                    <option value="shivalik">shivalik</option>
                    <option value="himadri">himadri</option>
                </select>

                <label>Room No:</label>
                <input type="text" name="room_no" required>

                <?php
                $fields = [
                    'bedsheet_cleanliness',
                    'room_cleanliness',
                    'condiment_tray',
                    'ac',
                    'fan',
                    'geyser',
                    'kettle',
                    'handwash',
                    'washroom'
                ];
                foreach ($fields as $field):
                ?>
                    <div class="rating-group">
                        <label><?= ucwords(str_replace("_", " ", $field)) ?>:</label>
                        <div class="stars">
                            <?php for ($i = 5; $i >= 1; $i--): ?>
                                <input type="radio" name="<?= $field ?>" id="<?= $field ?>-<?= $i ?>" value="<?= $i ?>" required>
                                <label for="<?= $field ?>-<?= $i ?>">★</label>
                            <?php endfor; ?>
                        </div>
                    </div>
                <?php endforeach; ?>

                <!--<label for="remarks">Remarks (Optional):</label><br>-->
                <!--<textarea name="remarks" rows="4" style="display: none; width: 100%;"></textarea>-->

                <input type="submit" name="submit_feedback" value="Submit Feedback">
            </form>
        <?php endif; ?>
    <?php endif; ?>
</div>
</body>
</html>
