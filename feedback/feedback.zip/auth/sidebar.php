<?php
?>
<style>
.sidebar {
  width: 220px;
  height: 100vh;
  position: fixed;
  background: #343a40;
  padding: 20px;
  color: white;
}
.sidebar a {
  display: block;
  color: #ffffff;
  padding: 10px;
  margin-bottom: 5px;
  text-decoration: none;
  border-radius: 4px;
}
.sidebar a:hover {
  background-color: #495057;
  color: #fff;
}
.main-content {
  margin-left: 240px;
  padding: 20px;
}
</style>
<div class="sidebar">
  <h4>Dashboard</h4>
  <a href="../course/add_course.php">Course</a> 
  <a href="../hostel_report.php">Hostel Report</a>
  <a href="../report.php">Mess Report User</a>
  <a href="../auth/register.php">Register Admin</a>
  <a href="logout.php">Logout</a>
</div>
