<?php
include 'auth_check.php';
require_once '../db_config.php';

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $conn->real_escape_string($_POST['username']);
    $password = hash('sha256', $_POST['password']);

    $check = $conn->query("SELECT * FROM auth WHERE username = '$username'");
    if ($check->num_rows > 0) {
        $error = "Username already exists.";
    } else {
        $query = "INSERT INTO auth (username, password) VALUES ('$username', '$password')";
        if ($conn->query($query)) {
            $success = "Registration successful.";
        } else {
            $error = "Error registering user.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Register</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include 'sidebar.php'; ?>
<div class="main-content">
  <div class="container">
    <h2>Register User</h2>
    <?php if ($success): ?>
      <div class="alert alert-success"><?= $success ?></div>
    <?php elseif ($error): ?>
      <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>
    <form method="POST">
      <div class="mb-3">
        <label class="form-label">Username</label>
        <input type="text" name="username" class="form-control" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-control" required>
      </div>
      <button class="btn btn-primary" type="submit">Register</button>
    </form>
  </div>
</div>
</body>
</html>
